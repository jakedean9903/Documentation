import java.util.Scanner;
/**
 * The SumOfNumbers class.
 * 
 * This class asks the user for a positive nonzero integer value. 
 * The program should use a loop to get the sum of all the integers 
 * from 1 up to the number entered.
 *
 * @author Jacob Dupuis 
 * @version 10/5/2021
 */
public class SumOfNumbers
{
    /**
     * Main method.
     * 
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args)
    {
        //creates scanner and int variable
        Scanner scanner = new Scanner(System.in);
        int inputNumber = -1;
        int total = 0;

        System.out.println("Please enter a positive integer: ");
        inputNumber = scanner.nextInt();
        while (inputNumber < 1)
        {
            //asks the user for input
            System.out.println("That is not a positive integer!");
            System.out.println("Please enter a positive integer: ");
            inputNumber = scanner.nextInt();

        }
        for (int number = 1; number <= inputNumber; number++)
        {
            total += number;
        }

        //sum output
        System.out.println(total); 

    }
}

